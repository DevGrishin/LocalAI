# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for module_appLocalAI_aotstats_target.
